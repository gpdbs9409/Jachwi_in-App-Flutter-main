package com.example.ja_chuiin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
