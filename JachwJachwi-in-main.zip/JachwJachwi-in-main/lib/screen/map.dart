import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_naver_map/flutter_naver_map.dart';
import 'package:ja_chuiin/screen/1.log_in.dart';



class MyMAP extends StatelessWidget {

  Color myColor = Color.fromARGB(255, 86, 20, 123);

  @override
  Widget build(BuildContext context) {
    double deviceWidth = MediaQuery.of(context).size.width;
  double deviceHeight = MediaQuery.of(context).size.height;
    return Scaffold(
        appBar: AppBar(
          title:Text('자취인'),
          actions: <Widget>[
            IconButton( // 오른쪽에 위치하는 첫 번째 버튼
              icon: Icon(Icons.search), // 원하는 아이콘으로 변경 가능
              onPressed: () {
              },
            ),


            IconButton( // 오른쪽에 위치하는 두 번째 버튼
              icon: Icon(Icons.settings), // 원하는 아이콘으로 변경 가능
              onPressed: () {   Navigator.push(
                  context,MaterialPageRoute(builder: (context)=>LOGIN())
              );
              },
            ),
          ],
          toolbarHeight: deviceHeight*0.1,
          backgroundColor: myColor, // 앱바의 배경색을 myColor로 설정합니다.
        ),
      body:
         Column(children:[
           SizedBox(height: deviceHeight*0.05,),
           Row(  children:[ TextButton(
             style: ButtonStyle(
               backgroundColor: MaterialStateProperty.all(Color(0xFFD9D9D9)),
             ),
             child: Text(
               '방구해요',
               style: TextStyle(color: Colors.black),
             ),
             onPressed: () {
               Navigator.push(
                 context,
                 MaterialPageRoute(builder: (context) => LOGIN()),
               );
             },
           )],),
      Container(

        width: 0.5*deviceWidth,
          height: 0.5*deviceHeight,
          child: NaverMap(
        options: const NaverMapViewOptions(
          initialCameraPosition: NCameraPosition(
            target: NLatLng(37.5666102, 126.9783881),
            zoom: 15,
            bearing: 45,
            tilt: 30,
          ),
          rotationGesturesEnable: true,
          scrollGesturesEnable: true,
          tiltGesturesEnable: true,
          zoomGesturesEnable: true,
          stopGesturesEnable: true,
        ),
        // 지도 옵션을 설정할 수 있습니다.
        forceGesture: false, // 지도에 전달되는 제스처 이벤트의 우선순위를 가장 높게 설정할지 여부를 지정합니다.
        onMapReady: (controller) {},
        onMapTapped: (point, latLng) {},
        onSymbolTapped: (symbol) {},
        onCameraChange: (position, reason) {},
        onCameraIdle: () {},
        onSelectedIndoorChanged: (indoor) {},
      )
    ),]),
      );
  }
}
