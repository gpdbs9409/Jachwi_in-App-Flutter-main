import 'package:flutter/material.dart';

class setting extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _settingState();
  }
}

class _settingState extends State<setting> {
  @override
  Widget build(BuildContext context) {
  return Text("세팅");
  }}