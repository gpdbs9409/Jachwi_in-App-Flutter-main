import 'package:flutter/material.dart';
class mypage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _mypageState();
  }
}

class _mypageState extends State<mypage> {
  @override
  Widget build(BuildContext context) {
  return Text('마이페이지');
  }}