import 'package:flutter/material.dart';

class UserInform {
  final String whatinform;
  final IconData icon;
  final ValueChanged<String> onChanged;

  UserInform({
    required this.whatinform,
    required this.icon,
    required this.onChanged,
  });
}
List<UserInform> userInforms = [
  UserInform(
    whatinform: 'Enter your username',
    icon: Icons.person,
    onChanged: (value) {
      print('Username changed: $value');
    },
  ),
  UserInform(
    whatinform: 'Enter your email',
    icon: Icons.email,
    onChanged: (value) {
      print('Email changed: $value');
    },
  ),
  UserInform(
    whatinform: 'Enter your password',
    icon: Icons.lock,
    onChanged: (value) {
      print('Password changed: $value');
    },
  ),
];

